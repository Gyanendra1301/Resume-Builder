from django.shortcuts import render
from django.http import HttpResponse

def home(request):
   return render(request ,'form_index.html', )

def Create(request):
    Name= 'name'
    params ={'NAme':Name}
    return render(request ,'Resume.html',params)





